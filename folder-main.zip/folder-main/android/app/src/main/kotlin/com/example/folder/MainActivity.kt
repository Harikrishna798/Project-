package com.example.folder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
